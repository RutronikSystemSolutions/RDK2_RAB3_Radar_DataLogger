﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RAB3RadarDistanceMeasurementGUI
{
    public class MeasurementConfiguration
    {
        public double threshold = -30;
        public int skipAtStart = 4;
    }
}
